﻿using FinchAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FInchRussell
{
    class Program
    {
        static void Main(string[] args)
        {
            SetTheme();

            DisplayWelcomeScreen();
            DisplayMainMenuScreen();
            
        }
        static void SetTheme()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.BackgroundColor = ConsoleColor.White;
        }

        static void DisplayMainMenuScreen()
        {
            //
            //  MAIN MENU
            //
            Console.CursorVisible = true;
            bool quitApplication = false;
            string menuChoice;
            //This creates a new Finch object
            Finch Reznor = new Finch();

            do
            {
                DisplayHeader("\tWelcome to the Finch Menu!");
                Console.WriteLine("\n\t\ta) Connect Finch Robot named Reznor");
                Console.WriteLine("\t\tb) Talent Show");
                Console.WriteLine("\t\tc) Data Recorder");
                Console.WriteLine("\t\td) Alarm System");
                Console.WriteLine("\t\te) User Programming");
                Console.WriteLine("\t\tf) Disconnect Finch Robot");
                Console.WriteLine("\t\tq) Quit");
                Console.Write("\t\t\tEnter your choice Please:");
                menuChoice = Console.ReadLine().ToLower();

                switch (menuChoice)
                {
                    case "a":
                        DisplayConnectFinchRobot(Reznor);
                        break;

                    case "b":
                        TalentShowDisplayMenuScreen(Reznor);
                        break;

                    case "c":
                        DataRecorderDisplayMenuScreen(Reznor);
                        break;

                    case "d":
                        AlarmSystemDisplayMenuScreen(Reznor);
                        break;

                    case "e":
                        UserProgrammingDisplayMenuScreen(Reznor);
                        break;

                    case "f":
                        DisplayDisconnectFinchRobot(Reznor);
                        break;

                    case "q":
                        DisplayClosingScreen(Reznor);
                        quitApplication = true;
                        break;

                    default:
                        Console.WriteLine("\t\nPlease enter a letter for the menu choice");
                        DisplayContinuePromt();
                        break;
                }
            } while (!quitApplication);
        }

        static void UserProgrammingDisplayMenuScreen(Finch Reznor)
        {
            DisplayHeader("You shouldn't be here yet!");

            Console.WriteLine("\n\t\tThis part of the program is still under construction! Please return later!");
            Console.WriteLine("OK love you byeeeeeeeeeeeeeeeeeeee");

            DisplayContinuePromt();
        }

        static void AlarmSystemDisplayMenuScreen(Finch Reznor)
        {
            DisplayHeader("You Shouldn't BE HERE");

            Console.WriteLine("\n\t\tThis part of the program is still under construction! Please return later!");
            Console.WriteLine("OK love you byeeeeeeeeeeeeeeeeeeee");

            DisplayContinuePromt();
        }

        static void DataRecorderDisplayMenuScreen(Finch Reznor)
        {
            DisplayHeader("Sorry this area isn't ready yet!");

            Console.WriteLine("\n\t\tThis part of the program is still under construction! Please return later!");
            Console.WriteLine("OK love you byeeeeeeeeeeeeeeeeeeee");

            DisplayContinuePromt();

        }

        static void TalentShowDisplayMenuScreen(Finch Reznor)
        {
            Console.CursorVisible = true;

            bool quitTalentShow = false;
            string menuChoice;

            do
            {
                DisplayHeader("Talent Show Time!");
                Console.WriteLine("\n\ta) Light and Sound");
                Console.WriteLine("\tb) Dance");
                Console.WriteLine("\tc) Mixing it up");
                Console.WriteLine("\tq) Return to Main Menu");
                Console.Write("\t\tEnter Choice Please:");
                menuChoice = Console.ReadLine().ToLower();

                DisplayContinuePromt();

                switch (menuChoice)
                {
                    case "a":
                        LightAndSound(Reznor);
                        break;

                    case "b":
                        DanceMenu(Reznor);
                        break;

                    case "c":
                        MixItUpMenu(Reznor);
                        break;

                    case "q":
                        DisplayMenuPrompt("Main");
                        quitTalentShow = true;
                        break;

                    default:
                        Console.WriteLine("\t\nPlease enter a letter for the menu choice");
                        DisplayContinuePromt();
                        break;
                }
            } while (!quitTalentShow);
        }

        static void DanceMenu(Finch Reznor)
        {
            Console.CursorVisible = false;

            DisplayHeader("Lets DANCE!");
            Console.WriteLine("\n\tReznor will now dance for you!");
            DisplayContinuePromt();
            Reznor.setMotors(100, 100);
            Reznor.wait(3000);
            Reznor.setMotors(100, -100);
            Reznor.wait(3000);
            Reznor.setMotors(0, 0);
            Reznor.setMotors(-100, 100);
            Reznor.wait(3000);
            Reznor.setMotors(0, 0);
        
            Console.WriteLine("Wow! What incredibly inspired moves! Jealous much?");
            DisplayMenuPrompt("Talent Show");
        }

        static void MixItUpMenu(Finch Reznor)
        {
            Console.CursorVisible = false;

            DisplayHeader("Lets get silly up in here! Dancing! Light show! Music!\n");
            DisplayContinuePromt();
          
            Reznor.setLED(50, 100, 200);
            Reznor.noteOn(263);
            Reznor.setMotors(-100, 100);
            Reznor.wait(2000);
            Reznor.setMotors(0, 0);
            Reznor.setLED(100, 200, 0);
            Reznor.noteOn(138);
            Reznor.setMotors(100, -100);
            Reznor.wait(2000);
            Reznor.setLED(0, 50, 255);
            Reznor.noteOn(800);
            Reznor.setMotors(100, 100);
            Reznor.wait(2000);
            Reznor.setMotors(0, 0);
            Reznor.setLED(10, 20, 50);
            Reznor.noteOn(138);
            Reznor.setMotors(30, -30);
            Reznor.wait(2000);
            Reznor.setLED(50, 100, 200);
            Reznor.noteOn(263);
            Reznor.setMotors(-100, 100);
            Reznor.wait(2000);
            Reznor.setMotors(0, 0);
            Reznor.setLED(100, 200, 0);
            Reznor.noteOn(138);
            Reznor.setMotors(100, -100);
            Reznor.wait(2000);
            Reznor.setLED(0, 50, 255);
            Reznor.noteOn(800);
            Reznor.setMotors(100, 100);
            Reznor.wait(2000);
            Reznor.setMotors(0, 0);
            Reznor.setLED(10, 20, 50);
            Reznor.noteOn(138);
            Reznor.setMotors(30, -30);
            Reznor.wait(2000);
            Reznor.noteOff();
            Reznor.setLED(0, 0, 0);

            Console.WriteLine("Wow, wasn't that something!");

            DisplayMenuPrompt("Talent Show");

            //for (int allTheThings = 0; allTheThings < 1000 ; allTheThings ++)
            //{
            //    Reznor.setLED(30, 74, 100);
            //    Reznor.noteOn(allTheThings * 20);
            //    Reznor.setMotors(allTheThings, allTheThings);
            //    Reznor.setLED(100, 50, 60);
            //}
        }

        static void LightAndSound(Finch Reznor)
        {
            Console.CursorVisible = false;

            DisplayHeader("Light and Sound Time!");

            Console.WriteLine("\n\tReznor will now scream and glow rapidly!");
            DisplayContinuePromt();
            for (int lightSound = 0; lightSound < 500; lightSound++)
            {
                Reznor.setLED(lightSound, 0, lightSound);
                Reznor.noteOn(lightSound * 50);
            }
            Reznor.setLED(0, 0, 0);
            DisplayMenuPrompt("Talent Show");
        }

        static bool DisplayConnectFinchRobot(Finch Reznor)
        {
            Console.CursorVisible = false;

            bool robotConnected;

            DisplayHeader("Connect Finch Robot");

            Console.WriteLine("\n\nThe application is going to connect with Reznor now. Please don't remove the cord!");

            DisplayContinuePromt();
            
            //This connects it, this Finch is named Reznor.
            robotConnected = Reznor.connect();
            
            
            while(robotConnected)
            {
                Reznor.setLED(100, 0, 100);
                Reznor.noteOn(400);
                Reznor.wait(1000);
                Reznor.noteOff();
                Reznor.setLED(0, 0, 0);
                Console.WriteLine("Hooray! Reznor is ready to party now!");
                Console.ReadKey();
                break;

            }
            

            if(!(robotConnected))
            {
                Console.WriteLine("WARNING FAILURE TO CONNECT WARNING! Press any key to escape");
                Console.ReadKey();
            }
            return robotConnected;
            //use while loop to connect and confirm to the Finch Robot
            //Return a bool value indicating if the connection was successful
        }

        static void DisplayMenuPrompt(string menuName)
        {
            Console.WriteLine($"\n\tPress any key to go back to the {menuName} Menu");
            Console.ReadKey();
        }

        //RUSSELL YOU CHANGED BOOL TO VOID ON DISPLAYDISCONNECTFINCHROBOT
        static void DisplayDisconnectFinchRobot(Finch Reznor)
        {
            DisplayHeader("Disconnect Finch Robot named Reznor");

            Console.WriteLine("Done already!? Well Reznor will disconnect now. Please be patient!");
            Reznor.disConnect();
            Console.WriteLine("Our Finch friend Reznor has been disconnected.");

            DisplayContinuePromt();

        }

        static void DisplayWelcomeScreen()
        {
            Console.CursorVisible = false;

            Console.Clear();
            Console.WriteLine("\n\t\tRussells Finch Control!\n");

            DisplayContinuePromt();

        }

        static void DisplayClosingScreen(Finch Reznor)
        {
            Console.CursorVisible = false;

            Console.Clear();
            Console.WriteLine("\n\t\tThanks for playing with Reznor!\n");
            
            DisplayContinuePromt();
        }

        static void DisplayHeader(string headerText)
        {

            // DisplayHeader will return whatever is in the writeline in the app above.
            Console.Clear();
            Console.WriteLine("\n\t\t\n" + headerText);

        }

        static void DisplayContinuePromt()
        {   //
            // pause for user
            //
            Console.WriteLine();
            Console.WriteLine("Press any key to continue!");
            Console.ReadKey();
        }
        
        static void PushPullTest()
        {
            //this is just a test to push and then pull to be different branches.
            Console.WriteLine("I understand that no one will ever get here with the program.");
        }
    }
}
